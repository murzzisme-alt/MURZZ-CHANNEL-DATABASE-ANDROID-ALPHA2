# MURZZ CHANNEL DATABASE Android — Alpha 2 Build 2

## Cara memasukkan source ke repository baru

1. Buat repository GitHub baru bernama `MURZZ-CHANNEL-DATABASE-ANDROID-ALPHA2-BUILD2`.
2. Pilih Private jika source ingin disimpan pribadi.
3. Jangan menambahkan README, license, atau .gitignore otomatis.
4. Ekstrak ZIP ini di perangkat Anda.
5. Unggah **isi folder ZIP** ke root repository, bukan file ZIP-nya dan bukan folder pembungkusnya.
6. Pastikan root repository langsung menampilkan `app/`, `.github/`, `settings.gradle.kts`, `build.gradle.kts`, dan `gradle.properties`.
7. Commit ke branch `main`.
8. Buka Actions, pilih `MURZZ Android Alpha 2 Build 2`, lalu jalankan `Run workflow` bila diperlukan.
9. Jika sukses, unduh artifact `MURZZ-CHANNEL-DATABASE-ALPHA2-BUILD2-APK`.

## Struktur root yang diwajibkan

```text
.github/workflows/alpha2-build.yml
app/build.gradle.kts
app/src/main/AndroidManifest.xml
app/src/main/java/com/murzz/channeldatabase/MainActivity.kt
build.gradle.kts
gradle.properties
settings.gradle.kts
README_ID.md
```

Jangan mengunggah ZIP ini sebagai satu file ke repository. GitHub Actions tidak otomatis mengekstrak arsip source; file proyek harus diunggah sebagai file/folder repository.

## Status

Ini adalah source Alpha 2 Build 2. APK belum dinyatakan teruji sampai GitHub Actions selesai dengan status Success dan APK diuji pada perangkat Android.
