package com.murzz.channeldatabase

import android.content.ContentResolver
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.unit.dp
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

private data class ChannelRecord(val id: String, val json: JSONObject, val updated: Long)

private fun jsonPretty(value: Any?): String = when (value) {
    is JSONObject -> value.toString(2)
    is org.json.JSONArray -> value.toString(2)
    else -> value?.toString() ?: "{}"
}

class MainActivity : ComponentActivity() {
    private lateinit var store: ChannelStore
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = ChannelStore(filesDir)
        setContent { MaterialTheme { DatabaseScreen(store, contentResolver) } }
    }
}

/** Stores desktop-shaped channel JSON. Unknown JSON fields are preserved when editing. */
private class ChannelStore(private val root: File) {
    private val channels = File(root, "channels").apply { mkdirs() }
    private val backups = File(root, "backup").apply { mkdirs() }
    private val trash = File(root, "terhapus").apply { mkdirs() }
    private fun file(id: String) = File(channels, "$id.json")

    fun list(): List<ChannelRecord> = channels.listFiles { f -> f.isFile && f.extension.equals("json", true) }
        ?.mapNotNull { f -> try { ChannelRecord(f.nameWithoutExtension, JSONObject(f.readText(Charsets.UTF_8)), f.lastModified()) } catch (_: Exception) { null } }
        ?.sortedByDescending { it.updated } ?: emptyList()

    fun save(id: String?, input: JSONObject): ChannelRecord {
        val safeId = id ?: (SimpleDateFormat("yyyyMMdd", Locale.US).format(Date()) + "-" + UUID.randomUUID().toString().replace("-", "").take(8))
        val target = file(safeId)
        if (target.exists()) backup(target)
        val obj = JSONObject(input.toString())
        val oldMeta = obj.optJSONObject("_meta") ?: JSONObject()
        val now = System.currentTimeMillis() / 1000.0
        val meta = JSONObject()
            .put("id", safeId)
            .put("created", oldMeta.optDouble("created", now))
            .put("updated", now)
            .put("app", "MURZZ Channel Database")
            .put("version", "4.0.2-android")
        obj.put("_meta", meta)
        atomicWrite(target, obj.toString(2))
        return ChannelRecord(safeId, obj, target.lastModified())
    }

    fun importJson(resolver: ContentResolver, uri: Uri): ChannelRecord {
        val raw = resolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
            ?: throw IllegalArgumentException("File tidak dapat dibaca.")
        val obj = try { JSONObject(raw) } catch (e: Exception) { throw IllegalArgumentException("JSON tidak valid atau bukan objek channel MURZZ.") }
        if (!obj.has("channel") && !obj.has("konten") && !obj.has("brief")) {
            throw IllegalArgumentException("Format tidak dikenali sebagai data channel MURZZ.")
        }
        // Import as a new record like the desktop app; never silently overwrite an existing channel.
        return save(null, obj)
    }

    fun export(resolver: ContentResolver, uri: Uri, record: ChannelRecord) {
        // Desktop export_channel exports channel data without the internal _meta field.
        val out = JSONObject(record.json.toString()).apply { remove("_meta") }
        resolver.openOutputStream(uri, "wt")?.bufferedWriter(Charsets.UTF_8)?.use { it.write(out.toString(2)) }
            ?: throw IllegalArgumentException("Tidak bisa menulis file tujuan.")
    }

    fun delete(record: ChannelRecord) {
        val source = file(record.id)
        if (!source.exists()) return
        val stamp = SimpleDateFormat("yyyyMMddHHmmss", Locale.US).format(Date())
        val target = File(trash, "${record.id}-$stamp.json")
        if (!source.renameTo(target)) {
            backup(source)
            if (!source.delete()) throw IllegalStateException("Gagal memindahkan channel ke cadangan penghapusan.")
        }
    }

    private fun backup(source: File) {
        val stamp = SimpleDateFormat("yyyyMMdd-HHmmss-SSS", Locale.US).format(Date())
        source.copyTo(File(backups, "${source.nameWithoutExtension}-$stamp.json"), overwrite = false)
    }

    private fun atomicWrite(target: File, content: String) {
        val temp = File(target.parentFile, target.name + ".tmp")
        temp.writeText(content, Charsets.UTF_8)
        if (target.exists() && !target.delete()) { temp.delete(); throw IllegalStateException("Tidak dapat mengganti data lama.") }
        if (!temp.renameTo(target)) { temp.copyTo(target, overwrite = true); temp.delete() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DatabaseScreen(store: ChannelStore, resolver: ContentResolver) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val clipboard = LocalClipboardManager.current
    var records by remember { mutableStateOf(store.list()) }
    var selectedId by remember { mutableStateOf<String?>(null) }
    var draft by remember { mutableStateOf(JSONObject()) }
    var channelName by remember { mutableStateOf("") }
    var brief by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var keywords by remember { mutableStateOf("") }
    var country by remember { mutableStateOf("") }
    var defaultDescription by remember { mutableStateOf("") }
    var defaultTags by remember { mutableStateOf("") }
    var query by remember { mutableStateOf("") }
    var itemQuery by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var error by remember { mutableStateOf(false) }
    var deleteTarget by remember { mutableStateOf<ChannelRecord?>(null) }
    var tabIndex by remember { mutableIntStateOf(0) }
    var expandedItem by remember { mutableIntStateOf(-1) }
    var itemEditor by remember { mutableStateOf("") }
    var itemFields by remember { mutableStateOf(mapOf<String, String>()) }
    var showRawJson by remember { mutableStateOf(false) }
    var objectEditors by remember { mutableStateOf(mapOf<String, String>()) }
    var exportName by remember { mutableStateOf("murzz-channel.json") }

    val tabs = listOf("Profil", "Logo & Banner", "Konten", "Thumbnail", "Suno", "Riset AI", "Mapping", "Scene Cue", "Jadwal", "Agent Mode")
    val arrayKeys = mapOf(2 to "konten", 3 to "thumb", 4 to "suno", 5 to "riset", 6 to "mapping", 7 to "scene")
    val objectKeys = mapOf(1 to listOf("logo", "banner"), 8 to listOf("jadwal"), 9 to listOf("agent"))

    fun load(record: ChannelRecord?) {
        selectedId = record?.id
        draft = record?.json?.let { JSONObject(it.toString()).apply { remove("_meta") } } ?: JSONObject()
        channelName = draft.optString("channel")
        brief = draft.optString("brief")
        description = draft.optString("deskripsi")
        keywords = draft.optString("keyword")
        country = draft.optString("negara")
        defaultDescription = draft.optString("def_desc")
        defaultTags = draft.optString("def_tags")
        itemQuery = ""; expandedItem = -1; itemEditor = ""; itemFields = emptyMap(); showRawJson = false; objectEditors = emptyMap()
        exportName = ((channelName.ifBlank { "murzz-channel" }.replace(Regex("[^A-Za-z0-9._ -]"), "").trim().replace(Regex("\\s+"), "-").ifBlank { "murzz-channel" }) + ".json")
    }
    fun refresh() { records = store.list() }
    fun currentJson(): JSONObject = JSONObject(draft.toString()).apply {
        put("channel", channelName); put("brief", brief); put("deskripsi", description)
        put("keyword", keywords); put("negara", country); put("def_desc", defaultDescription); put("def_tags", defaultTags)
        if (!has("logo")) put("logo", JSONObject().put("path", "").put("note", ""))
        if (!has("banner")) put("banner", JSONObject().put("path", "").put("note", ""))
        listOf("konten", "thumb", "suno", "riset", "mapping", "scene").forEach { if (!has(it)) put(it, org.json.JSONArray()) }
        if (!has("jadwal")) put("jadwal", JSONObject().put("hari", org.json.JSONArray()).put("jam", "").put("zona", "WIB").put("catatan", ""))
        if (!has("thumb_mode")) put("thumb_mode", "A")
        if (!has("agent")) put("agent", JSONObject().put("n_var", 0).put("blocks", org.json.JSONArray()))
    }
    fun copyText(text: String, label: String) {
        clipboard.setText(AnnotatedString(text)); message = "$label berhasil disalin."; error = false
    }
    fun visualItemJson(): JSONObject {
        val obj = try { JSONObject(itemEditor.ifBlank { "{}" }) } catch (_: Exception) { JSONObject() }
        itemFields.forEach { (key, value) -> obj.put(key, value) }
        return obj
    }
    fun fieldsForTab(index: Int): List<Pair<String, String>> = when (index) {
        2 -> listOf("judul" to "Judul", "deskripsi" to "Deskripsi", "tags" to "Tags", "nomor" to "Nomor")
        3 -> listOf("text" to "Prompt thumbnail", "nomor" to "Nomor")
        4 -> listOf("judul" to "Judul", "tipe" to "Tipe", "lyrics" to "Lyrics", "style_full" to "Style lengkap", "style_short" to "Style singkat", "exclude" to "Exclude", "weirdness" to "Weirdness", "influence" to "Style influence")
        5 -> listOf("kategori" to "Kategori", "judul" to "Judul", "text" to "Isi riset")
        6 -> listOf("nomor" to "Nomor", "ref_id" to "Reference ID", "mode" to "Mode", "judul" to "Judul")
        7 -> listOf("nomor" to "Nomor", "pilar" to "Pilar", "cue" to "Scene cue")
        else -> emptyList()
    }
    fun saveItem() {
        try {
            val arr = draft.optJSONArray(arrayKeys[tabIndex] ?: return) ?: org.json.JSONArray()
            val obj = visualItemJson()
            val rebuilt = org.json.JSONArray()
            for (i in 0 until arr.length()) rebuilt.put(if (i == expandedItem) obj else arr.get(i))
            draft.put(arrayKeys[tabIndex]!!, rebuilt)
            itemEditor = obj.toString(2)
            message = "Data item diterapkan ke draft. Tekan Simpan Channel untuk menyimpan permanen."; error = false
        } catch (e: Exception) { message = "Data item belum valid: ${e.message ?: "periksa format"}"; error = true }
    }

    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) try { val r = store.importJson(resolver, uri); refresh(); load(r); message = "Channel berhasil diimpor sebagai data baru."; error = false } catch (e: Exception) { message = e.message ?: "Impor gagal."; error = true }
    }
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) try {
            val id = selectedId
            val record = if (id == null) null else records.firstOrNull { it.id == id }
            if (record == null) throw IllegalStateException("Simpan atau pilih channel terlebih dahulu.")
            val fresh = ChannelRecord(record.id, currentJson(), record.updated)
            store.export(resolver, uri, fresh); message = "Ekspor JSON selesai."; error = false
        } catch (e: Exception) { message = e.message ?: "Ekspor gagal."; error = true }
    }

    Scaffold(topBar = { TopAppBar(title = { Text("MURZZ CHANNEL DATABASE", fontWeight = FontWeight.Bold) }) }) { padding ->
        Column(Modifier.padding(padding).fillMaxSize().padding(horizontal = 12.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Button(onClick = { load(null); tabIndex = 0; message = "Channel baru. Isi nama lalu simpan." }) { Text("+ Baru") }
                OutlinedButton(onClick = { importLauncher.launch(arrayOf("application/json", "text/json", "text/plain")) }) { Text("Impor") }
                OutlinedButton(onClick = { if (selectedId == null) { message = "Pilih dan simpan channel dahulu."; error = true } else exportLauncher.launch(exportName.ifBlank { "murzz-channel.json" }) }) { Text("Ekspor") }
            }
            OutlinedTextField(value = query, onValueChange = { query = it }, label = { Text("Cari channel") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            LazyColumn(Modifier.heightIn(max = 150.dp).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                items(records.filter { it.json.optString("channel").contains(query, true) || query.isBlank() }, key = { it.id }) { record ->
                    Card(onClick = { load(record); message = "Channel dipilih." }, colors = CardDefaults.cardColors(containerColor = if (record.id == selectedId) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surfaceVariant), modifier = Modifier.fillMaxWidth()) {
                        Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column(Modifier.weight(1f)) {
                                Text(record.json.optString("channel").ifBlank { "(Tanpa nama)" }, fontWeight = FontWeight.SemiBold)
                                Text("${record.json.optJSONArray("konten")?.length() ?: 0} konten • ${record.json.optJSONArray("thumb")?.length() ?: 0} thumbnail", style = MaterialTheme.typography.bodySmall)
                            }
                            TextButton(onClick = { deleteTarget = record }) { Text("Hapus", color = MaterialTheme.colorScheme.error) }
                        }
                    }
                }
            }
            HorizontalDivider()
            ScrollableTabRow(selectedTabIndex = tabIndex, edgePadding = 0.dp) {
                tabs.forEachIndexed { i, title -> Tab(selected = tabIndex == i, onClick = { tabIndex = i; expandedItem = -1; itemEditor = ""; itemFields = emptyMap(); showRawJson = false; objectEditors = emptyMap(); itemQuery = "" }, text = { Text(title, maxLines = 1) }) }
            }
            Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                when (tabIndex) {
                    0 -> {
                        Text(if (selectedId == null) "Profil channel baru" else "Profil channel", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        OutlinedTextField(channelName, { channelName = it; exportName = it.replace(Regex("[^A-Za-z0-9._ -]"), "").trim().replace(Regex("\\s+"), "-").ifBlank { "murzz-channel" } + ".json" }, label = { Text("Nama channel *") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        OutlinedTextField(brief, { brief = it }, label = { Text("Brief branding") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                        OutlinedTextField(description, { description = it }, label = { Text("Deskripsi channel") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                        OutlinedTextField(keywords, { keywords = it }, label = { Text("Keyword") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                        OutlinedTextField(country, { country = it }, label = { Text("Negara") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        OutlinedTextField(defaultDescription, { defaultDescription = it }, label = { Text("Default upload description") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                        OutlinedTextField(defaultTags, { defaultTags = it }, label = { Text("Default tags") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                        OutlinedTextField(exportName, { exportName = it }, label = { Text("Nama file ekspor") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        OutlinedButton(onClick = { copyText("Channel: $channelName\nBrief: $brief\nDeskripsi: $description\nKeyword: $keywords\nNegara: $country\nDefault description: $defaultDescription\nDefault tags: $defaultTags", "Profil") }, modifier = Modifier.fillMaxWidth()) { Text("Salin semua data profil") }
                    }
                    in 2..7 -> {
                        val key = arrayKeys[tabIndex]!!
                        val arr = draft.optJSONArray(key) ?: org.json.JSONArray()
                        Text("${tabs[tabIndex]} • ${arr.length()} item", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        OutlinedTextField(itemQuery, { itemQuery = it }, label = { Text("Cari ${tabs[tabIndex].lowercase()}") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { val rebuilt = org.json.JSONArray(); for (i in 0 until arr.length()) rebuilt.put(arr.get(i)); rebuilt.put(JSONObject()); draft.put(key, rebuilt); expandedItem = rebuilt.length()-1; itemEditor = "{}"; itemFields = fieldsForTab(tabIndex).associate { it.first to "" }; showRawJson = false; message = "Item baru ditambahkan ke draft."; error = false }) { Text("+ Item") }
                            OutlinedButton(onClick = { copyText((0 until arr.length()).joinToString("\n\n") { arr.optJSONObject(it)?.toString(2) ?: arr.get(it).toString() }, "Semua item") }) { Text("Salin semua") }
                        }
                        for (i in 0 until arr.length()) {
                            val item = arr.optJSONObject(i)
                            val summary = item?.optString("judul")?.takeIf { it.isNotBlank() }
                                ?: item?.optString("nama")?.takeIf { it.isNotBlank() }
                                ?: item?.optString("title")?.takeIf { it.isNotBlank() }
                                ?: item?.optString("nomor")?.takeIf { it.isNotBlank() }?.let { "Item $it" }
                                ?: "Item ${i+1}"
                            if (itemQuery.isBlank() || summary.contains(itemQuery, true) || (item?.toString() ?: arr.opt(i).toString()).contains(itemQuery, true)) {
                                Card(Modifier.fillMaxWidth()) {
                                    Column(Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Row(horizontalArrangement = Arrangement.SpaceBetween) {
                                            Column(Modifier.weight(1f)) { Text(summary, fontWeight = FontWeight.SemiBold); Text("Ketuk untuk membuka detail", style = MaterialTheme.typography.bodySmall) }
                                            TextButton(onClick = { if (expandedItem == i) { expandedItem = -1 } else { expandedItem = i; itemEditor = jsonPretty(arr.opt(i)); val obj = arr.optJSONObject(i) ?: JSONObject(); itemFields = fieldsForTab(tabIndex).associate { it.first to obj.optString(it.first, "") }; showRawJson = false } }) { Text(if (expandedItem == i) "Tutup" else "Detail") }
                                        }
                                        if (expandedItem == i) {
                                            fieldsForTab(tabIndex).forEach { (field, label) ->
                                                OutlinedTextField(value = itemFields[field] ?: "", onValueChange = { itemFields = itemFields + (field to it) }, label = { Text(label) }, modifier = Modifier.fillMaxWidth(), minLines = if (field in listOf("deskripsi", "lyrics", "style_full", "text", "cue")) 2 else 1)
                                            }
                                            TextButton(onClick = { showRawJson = !showRawJson }) { Text(if (showRawJson) "Tutup JSON lanjutan" else "JSON lanjutan / field tambahan") }
                                            if (showRawJson) OutlinedTextField(value = itemEditor, onValueChange = { itemEditor = it }, label = { Text("JSON mentah (field tambahan desktop)") }, modifier = Modifier.fillMaxWidth(), minLines = 5)
                                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                                                OutlinedButton(onClick = { copyText(visualItemJson().toString(2), "Item") }) { Text("Salin item") }
                                                OutlinedButton(onClick = { val clip = clipboard.getText()?.text; if (!clip.isNullOrBlank()) try { val parsed = JSONObject(clip); itemEditor = parsed.toString(2); itemFields = fieldsForTab(tabIndex).associate { it.first to parsed.optString(it.first, "") }; message = "JSON clipboard ditempelkan."; error = false } catch (_: Exception) { message = "Clipboard bukan objek JSON yang valid."; error = true } else { message = "Clipboard kosong."; error = true } }) { Text("Tempel JSON") }
                                                Button(onClick = { saveItem() }) { Text("Terapkan") }
                                                TextButton(onClick = { val newArr = org.json.JSONArray(); for (j in 0 until arr.length()) if (j != i) newArr.put(arr.get(j)); draft.put(key, newArr); expandedItem = -1; message = "Item dihapus dari draft; simpan channel untuk permanen."; error = false }) { Text("Hapus") }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    else -> {
                        val keys = objectKeys[tabIndex]!!
                        Text(tabs[tabIndex], style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        keys.forEach { key ->
                            val current = draft.opt(key)
                            Text(key.replaceFirstChar { it.uppercase() }, fontWeight = FontWeight.SemiBold)
                            OutlinedTextField(objectEditors[key] ?: jsonPretty(current), { value -> objectEditors = objectEditors + (key to value) }, label = { Text("JSON $key") }, modifier = Modifier.fillMaxWidth(), minLines = 5)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(onClick = { try { val parsed = org.json.JSONTokener(objectEditors[key] ?: jsonPretty(current)).nextValue(); draft.put(key, parsed); objectEditors = objectEditors - key; message = "$key diterapkan ke draft."; error = false } catch (e: Exception) { message = "JSON $key tidak valid."; error = true } }) { Text("Terapkan $key") }
                                OutlinedButton(onClick = { copyText(jsonPretty(draft.opt(key)), key) }) { Text("Salin") }
                                OutlinedButton(onClick = { val clip = clipboard.getText()?.text; if (!clip.isNullOrBlank()) { objectEditors = objectEditors + (key to clip); message = "Clipboard ditempelkan."; error = false } else { message = "Clipboard kosong."; error = true } }) { Text("Tempel") }
                            }
                        }
                        if (tabIndex == 1) Text("Edit logo dan banner sebagai objek JSON agar field desktop yang belum didukung tetap dapat dipertahankan.", style = MaterialTheme.typography.bodySmall)
                        if (tabIndex == 8) Text("Jadwal disimpan dalam struktur JSON desktop: hari, jam, zona, catatan.", style = MaterialTheme.typography.bodySmall)
                        if (tabIndex == 9) Text("Agent Mode disimpan dalam struktur JSON desktop: n_var dan blocks.", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            Button(onClick = {
                if (channelName.isBlank()) { message = "Nama channel wajib diisi."; error = true }
                else try { val r = store.save(selectedId, currentJson()); selectedId = r.id; refresh(); load(records.firstOrNull { it.id == r.id } ?: r); message = "Channel tersimpan."; error = false }
                catch (e: Exception) { message = e.message ?: "Gagal menyimpan."; error = true }
            }, modifier = Modifier.fillMaxWidth()) { Text("Simpan Channel") }
            if (message.isNotBlank()) Text(message, color = if (error) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall)
        }
    }
    if (deleteTarget != null) {
        val target = deleteTarget!!
        AlertDialog(onDismissRequest = { deleteTarget = null }, title = { Text("Hapus channel?") }, text = { Text("Channel '${target.json.optString("channel").ifBlank { "Tanpa nama" }}' akan dipindahkan ke folder cadangan penghapusan. Lanjutkan?") }, confirmButton = { TextButton(onClick = { try { store.delete(target); if (selectedId == target.id) load(null); refresh(); message = "Channel dipindahkan ke cadangan penghapusan."; error = false } catch (e: Exception) { message = e.message ?: "Penghapusan gagal."; error = true }; deleteTarget = null }) { Text("Hapus", color = MaterialTheme.colorScheme.error) } }, dismissButton = { TextButton(onClick = { deleteTarget = null }) { Text("Batal") } })
    }
}
